
import re
import os
import time
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver import ActionChains 
from selenium.common.exceptions import NoSuchElementException

def card_info(flg) :
    path = os.path.dirname(os.path.abspath(__file__))
    src = 'https://www.getcreditcardnumbers.com/'
    option = webdriver.ChromeOptions()
    option.add_argument("--headless")
    driver = webdriver.Chrome(os.path.expanduser('/opt/Wolfram/WolframEngine/12.1/SystemFiles/Components/WebUnit/Resources/DriverBinaries/ChromeDriver/Linux-ARM/chromedriver'),options = option)
    driver.get(src)
    time.sleep(1)    
    option_flag = flg #'AE' master card:MC, Aexpress: AE, visa:V, discover: D
    driver.find_element_by_xpath("//select[@name='card_type']/option[@value='" + str(option_flag)+"']").click()
    time.sleep(1)
    html = driver.page_source
    soup = BeautifulSoup(html, 'html.parser')
    driver.close()
    div = soup.find("span", {"class": "lit"})
    cardnumber=div.text
    return cardnumber
# card_info("V")
